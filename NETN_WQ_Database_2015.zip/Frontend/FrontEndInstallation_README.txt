Installation instructions for NETN_H2Ov2 Front End:

1) Copy entire "NETN_H2Ov2_FE" folder to appropriate destination on local computer.

2) Open front-end database "NETN_H2Ov2.mdb" and link all tables to most current version of backend database "NETN_H2O_BE.mdb" on Z: (MABI) or L: (ACAD) drive.